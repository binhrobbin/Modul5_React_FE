import logo from './logo.svg';
import './App.css';
import React from 'react'
import StudentList from "./components/student/StudentList";
import DemoState from "./components/DemoState";
import DemoStateFunc from "./components/DemoStateFunc";
import StudentListFunc from "./components/student/StudentListFunc";

function App() {
  const id ="c11";
  const nameClass = "c1123g1"
  const hello = (name) => {
    alert("Hello "+ name)
  }

  const students = [
    {
      id: '1'
    },
    {

    }
  ]
  return (
    // React.createElement("h1", {name: 'c11', id:'c11'}, "Xin chào C11")
  // <>
  //   <h1 id={id} name="c11">Xin chào</h1>
  //   <button onClick={() => hello('hai')}>A</button>
  // </>

  //     Hiển thị 1 mảng học sinh với thông tin id, name, address
  //     Giải thích tác dụng của key props
  //     Deadline 15h chiều nay

      <>
      {/*<StudentList nameClass = {nameClass}/>*/}
      {/*  <DemoStateFunc></DemoStateFunc>*/}
        <StudentListFunc/>
      </>
  );
}

export default App;
