export default function StudentList(props) {
    return (
        <>
            <h1>Danh sách học sinh</h1>
            <h1>{props.students[0].name}</h1>
        </>
    )
}

export const getServerSideProps = async () => {
//     Call API
    let temp = [
        {
            id: 1,
            name: "haiTT"
        }
    ]
    return {
        props: {
            students: temp,
            teacher: {}
        }
    }
}