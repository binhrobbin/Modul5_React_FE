export default function Home() {
    return (
        <>
        <h1>Xin chào các bạn</h1>
        </>
    )
}