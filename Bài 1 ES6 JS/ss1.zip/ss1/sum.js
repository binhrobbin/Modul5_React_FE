// function sum(a, b) {
//     console.log(a + b);
// }
//
// function sum(a, b) {
//     return sum = a + b
// }

// console.log(sum(3,5));
// function sum(a, b) {
//     return a + b
// }
// ->: java lambda // Java 8
// Arrow function
// Không có {} hoặc sử dụng () => thì mặc định là return
// let sum = (a,b) => a+b;

// Khác nhau của declare function và arrow function
// Arrow ngắn gọn hơn
// Arrow không có hoisted

// let Dog = (name, age) => {
//     this.name = name;
//     this.age = age;
// }
//
// let dog = new Dog("a", 1);

// This trong arrow
let obj = {
    a: 1,
    b: () => {
        console.log(this, this.a)
    },
    c: function () {
        console.log(this, this.a);
    }
}
obj.b();
obj.c();

